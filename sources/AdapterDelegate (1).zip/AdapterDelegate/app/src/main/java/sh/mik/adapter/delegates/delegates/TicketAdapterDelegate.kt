package sh.mik.adapter.delegates.delegates

import com.hannesdorfmann.adapterdelegates4.dsl.adapterDelegateViewBinding
import sh.mik.adapter.delegates.TicketItem
import sh.mik.adapter.delegates.adapter.DelegationAdapterItem
import sh.mik.adapter.delegates.databinding.ItemTicketBinding

fun ticketAdapterDelegate() =
    adapterDelegateViewBinding<TicketItem, DelegationAdapterItem, ItemTicketBinding>(
        viewBinding = { layoutInflater, root ->
            ItemTicketBinding.inflate(layoutInflater, root, false)
        }
    ) {

        bind {
            binding.ticket = item
        }
    }