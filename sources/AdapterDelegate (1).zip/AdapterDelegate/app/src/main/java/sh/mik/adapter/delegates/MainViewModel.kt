package sh.mik.adapter.delegates

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import sh.mik.adapter.delegates.adapter.DelegationAdapterItem
import kotlin.random.Random

class MainViewModel : ViewModel() {

    private val dataState = MutableLiveData<List<DelegationAdapterItem>>()

    fun getState(): LiveData<List<DelegationAdapterItem>> = dataState

    init {
        viewModelScope.launch {
            while (true) {
                val data = mutableListOf<DelegationAdapterItem>()
                data.add(
                    FlightItem(
                        1,
                        "Flight: ${Random.nextInt(1000, 9999)}"
                    )
                )
                val ticketsCount = Random.nextInt(1, 10)
                repeat(ticketsCount) { ticketId ->
                    data.add(
                        TicketItem(
                            ticketId,
                            "Ticket: ${Random.nextInt(1000, 9999)}"
                        )
                    )
                }
                dataState.value = data
                delay(2000)
            }
        }
    }
}