package sh.mik.adapter.delegates.adapter

interface DelegationAdapterItem {
    fun getId(): Any
    fun getContent(): Any
}