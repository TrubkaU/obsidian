package sh.mik.adapter.delegates.adapter

import android.annotation.SuppressLint
import androidx.recyclerview.widget.DiffUtil

class DelegationAdapterDiffCallback : DiffUtil.ItemCallback<DelegationAdapterItem>() {
    override fun areItemsTheSame(
        oldItem: DelegationAdapterItem,
        newItem: DelegationAdapterItem
    ): Boolean = oldItem::class == newItem::class && oldItem.getId() == newItem.getId()

    @SuppressLint("DiffUtilEquals")
    override fun areContentsTheSame(
        oldItem: DelegationAdapterItem,
        newItem: DelegationAdapterItem
    ): Boolean = oldItem::class == newItem::class && oldItem.getContent() == newItem.getContent()
}