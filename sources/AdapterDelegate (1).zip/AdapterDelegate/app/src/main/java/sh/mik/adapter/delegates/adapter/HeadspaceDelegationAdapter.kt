package sh.mik.adapter.delegates.adapter

import com.hannesdorfmann.adapterdelegates4.AdapterDelegate
import com.hannesdorfmann.adapterdelegates4.AsyncListDifferDelegationAdapter

class HeadspaceDelegationAdapter(
    vararg delegates: AdapterDelegate<List<DelegationAdapterItem>>,
) : AsyncListDifferDelegationAdapter<DelegationAdapterItem>(
    DelegationAdapterDiffCallback(),
    *delegates
)