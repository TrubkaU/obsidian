package sh.mik.adapter.delegates

import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.LinearLayoutManager
import com.hannesdorfmann.adapterdelegates4.ListDelegationAdapter
import sh.mik.adapter.delegates.adapter.DelegationAdapterItem
import sh.mik.adapter.delegates.adapter.HeadspaceDelegationAdapter
import sh.mik.adapter.delegates.databinding.ActivityMainBinding
import sh.mik.adapter.delegates.delegates.flightAdapterDelegate
import sh.mik.adapter.delegates.delegates.ticketAdapterDelegate

class MainActivity : AppCompatActivity() {

    private val viewModel by viewModels<MainViewModel>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val activityBinding: ActivityMainBinding = DataBindingUtil.setContentView(
            this, R.layout.activity_main
        )

        val adapter = HeadspaceDelegationAdapter(
            ticketAdapterDelegate(),
            flightAdapterDelegate(),
        )

        activityBinding.recycler.apply {
            this.adapter = adapter
            this.layoutManager =
                LinearLayoutManager(this.context, LinearLayoutManager.VERTICAL, false)
        }

        viewModel.getState().observe(this) { data ->
            adapter.items = data
        }
    }
}

data class TicketItem(
    val id: Int,
    val number: String,
) : DelegationAdapterItem {
    override fun getId() = id
    override fun getContent() = number
}

data class FlightItem(
    val id: Int,
    val time: String,
) : DelegationAdapterItem {
    override fun getId() = id
    override fun getContent() = time
}