package sh.mik.adapter.delegates.delegates

import com.hannesdorfmann.adapterdelegates4.dsl.adapterDelegateViewBinding
import sh.mik.adapter.delegates.FlightItem
import sh.mik.adapter.delegates.adapter.DelegationAdapterItem
import sh.mik.adapter.delegates.databinding.ItemFlightBinding

fun flightAdapterDelegate() =
    adapterDelegateViewBinding<FlightItem, DelegationAdapterItem, ItemFlightBinding>(
        viewBinding = { layoutInflater, root ->
            ItemFlightBinding.inflate(layoutInflater, root, false)
        }
    ) {

        bind {
            binding.flight = item
        }
    }